Admin roadmap:
- authenticate admins separately
- user suspension
- post moderation
- ticket reply/status controls
- reports queue
- creator verification
- platform analytics
