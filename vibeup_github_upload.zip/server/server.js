const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { Pool } = require("pg");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const NODE_ENV = process.env.NODE_ENV || "development";
const IS_PROD = NODE_ENV === "production";
const SECRET = process.env.JWT_SECRET || "dev-only-change-me";
const ROOT = path.join(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const UPLOADS = path.join(ROOT, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });

if (IS_PROD && SECRET === "dev-only-change-me") {
  throw new Error("JWT_SECRET must be set in production");
}

const allowedOrigins = (process.env.CORS_ORIGIN || "http://localhost:3000")
  .split(",").map(s => s.trim()).filter(Boolean);

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({ origin: allowedOrigins.length === 1 ? allowedOrigins[0] : allowedOrigins, credentials: false }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || undefined,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes("localhost") ? { rejectUnauthorized: false } : undefined,
  max: Number(process.env.DB_POOL_MAX || 10)
});

async function query(text, params = []) {
  return pool.query(text, params);
}

async function initDb() {
  await query(`
    CREATE TABLE IF NOT EXISTS users(
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      bio TEXT DEFAULT '',
      avatar TEXT DEFAULT '',
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS posts(
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      media TEXT NOT NULL,
      caption TEXT DEFAULT '',
      media_type TEXT DEFAULT 'image',
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS likes(
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
      PRIMARY KEY(user_id, post_id)
    );
    CREATE TABLE IF NOT EXISTS follows(
      follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      following_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      PRIMARY KEY(follower_id, following_id),
      CHECK(follower_id <> following_id)
    );
    CREATE TABLE IF NOT EXISTS messages(
      id SERIAL PRIMARY KEY,
      sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      receiver_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      read_at TIMESTAMPTZ
    );
    CREATE TABLE IF NOT EXISTS support_tickets(
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT DEFAULT 'open',
      reply TEXT DEFAULT '',
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(sender_id, receiver_id, id);
    CREATE INDEX IF NOT EXISTS idx_support_user ON support_tickets(user_id, id DESC);
  `);
}

const s3Enabled = Boolean(process.env.S3_BUCKET && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY && process.env.S3_PUBLIC_BASE_URL);
const s3 = s3Enabled ? new S3Client({
  region: process.env.S3_REGION || "auto",
  endpoint: process.env.S3_ENDPOINT || undefined,
  forcePathStyle: Boolean(process.env.S3_ENDPOINT),
  credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY }
}) : null;

const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /^(image|video)\//.test(file.mimetype);
    cb(ok ? null : new Error("Only image/video uploads are allowed"), ok);
  }
});

async function saveMedia(file) {
  const ext = path.extname(file.originalname).toLowerCase().replace(/[^a-z0-9.]/g, "");
  const safeExt = ext || (file.mimetype.startsWith("video/") ? ".mp4" : ".jpg");
  const key = `media/${new Date().toISOString().slice(0, 10)}/${crypto.randomUUID()}${safeExt}`;
  if (s3Enabled) {
    await s3.send(new PutObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key, Body: file.buffer, ContentType: file.mimetype, CacheControl: "public,max-age=31536000,immutable" }));
    return `${process.env.S3_PUBLIC_BASE_URL.replace(/\/$/, "")}/${key}`;
  }
  if (IS_PROD) throw new Error("Media storage is not configured. Set S3_* environment variables before production upload.");
  const localName = `${Date.now()}-${crypto.randomUUID()}${safeExt}`;
  fs.writeFileSync(path.join(UPLOADS, localName), file.buffer);
  return `/uploads/${localName}`;
}

function tokenFor(user) { return jwt.sign({ id: user.id }, SECRET, { expiresIn: "30d" }); }
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Authentication required" });
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { return res.status(401).json({ error: "Invalid or expired token" }); }
}
function cleanText(value, max) { return String(value ?? "").trim().slice(0, max); }
function validEmail(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); }

app.get("/api/health", async (req, res) => {
  try { await query("SELECT 1"); res.json({ ok: true, app: "VibeUp", database: "ok", media: s3Enabled ? "object-storage" : "local-dev", time: new Date().toISOString() }); }
  catch { res.status(503).json({ ok: false, app: "VibeUp", database: "unavailable" }); }
});

app.post("/api/auth/register", async (req, res, next) => {
  try {
    const username = cleanText(req.body.username, 30).toLowerCase().replace(/[^a-z0-9_.]/g, "");
    const name = cleanText(req.body.name, 80);
    const email = cleanText(req.body.email, 160).toLowerCase();
    const password = String(req.body.password || "");
    if (!username || username.length < 3 || !name || !validEmail(email) || password.length < 8) return res.status(400).json({ error: "Use a valid name, username, email and 8+ character password" });
    const hash = await bcrypt.hash(password, 12);
    const r = await query("INSERT INTO users(username,name,email,password) VALUES($1,$2,$3,$4) RETURNING id,username,name,email,bio,avatar", [username, name, email, hash]);
    const user = r.rows[0];
    res.status(201).json({ token: tokenFor(user), user });
  } catch (e) { if (e.code === "23505") return res.status(409).json({ error: "Username or email already exists" }); next(e); }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const email = cleanText(req.body.email, 160).toLowerCase();
    const password = String(req.body.password || "");
    const r = await query("SELECT * FROM users WHERE email=$1", [email]);
    const user = r.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ error: "Invalid email or password" });
    const safe = { id: user.id, username: user.username, name: user.name, email: user.email, bio: user.bio, avatar: user.avatar };
    res.json({ token: tokenFor(safe), user: safe });
  } catch (e) { next(e); }
});

app.get("/api/me", auth, async (req, res, next) => {
  try { const r = await query("SELECT id,username,name,email,bio,avatar,created_at FROM users WHERE id=$1", [req.user.id]); res.json(r.rows[0] || null); } catch (e) { next(e); }
});

app.get("/api/feed", auth, async (req, res, next) => {
  try {
    const r = await query(`SELECT p.*,u.username,u.name,u.avatar,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) AS likes,
      EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=$1) AS liked
      FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 50`, [req.user.id]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

app.post("/api/posts", auth, upload.single("media"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Media file required" });
    const media = await saveMedia(req.file);
    const type = req.file.mimetype.startsWith("video") ? "video" : "image";
    const r = await query("INSERT INTO posts(user_id,media,caption,media_type) VALUES($1,$2,$3,$4) RETURNING *", [req.user.id, media, cleanText(req.body.caption, 2200), type]);
    res.status(201).json(r.rows[0]);
  } catch (e) { next(e); }
});

app.post("/api/posts/:id/like", auth, async (req, res, next) => {
  try {
    const id = Number(req.params.id); if (!Number.isInteger(id)) return res.status(400).json({ error: "Invalid post" });
    const exists = await query("SELECT 1 FROM likes WHERE user_id=$1 AND post_id=$2", [req.user.id, id]);
    if (exists.rowCount) await query("DELETE FROM likes WHERE user_id=$1 AND post_id=$2", [req.user.id, id]);
    else await query("INSERT INTO likes(user_id,post_id) VALUES($1,$2) ON CONFLICT DO NOTHING", [req.user.id, id]);
    const count = await query("SELECT COUNT(*)::int AS c FROM likes WHERE post_id=$1", [id]);
    res.json({ liked: !exists.rowCount, likes: count.rows[0].c });
  } catch (e) { next(e); }
});

app.post("/api/users/:id/follow", auth, async (req, res, next) => {
  try {
    const target = Number(req.params.id); if (!Number.isInteger(target)) return res.status(400).json({ error: "Invalid user" });
    if (target === req.user.id) return res.status(400).json({ error: "Cannot follow yourself" });
    const exists = await query("SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2", [req.user.id, target]);
    if (exists.rowCount) await query("DELETE FROM follows WHERE follower_id=$1 AND following_id=$2", [req.user.id, target]);
    else await query("INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING", [req.user.id, target]);
    res.json({ following: !exists.rowCount });
  } catch (e) { next(e); }
});

app.get("/api/users/search", auth, async (req, res, next) => {
  try { const q = `%${String(req.query.q || "").replace(/[\\%_]/g, "")}%`; const r = await query("SELECT id,username,name,avatar FROM users WHERE username ILIKE $1 OR name ILIKE $1 ORDER BY username LIMIT 20", [q]); res.json(r.rows); } catch (e) { next(e); }
});

app.get("/api/messages/:userId", auth, async (req, res, next) => {
  try {
    const other = Number(req.params.userId); if (!Number.isInteger(other)) return res.status(400).json({ error: "Invalid user" });
    await query("UPDATE messages SET read_at=CURRENT_TIMESTAMP WHERE sender_id=$1 AND receiver_id=$2 AND read_at IS NULL", [other, req.user.id]);
    const r = await query(`SELECT m.*,s.username AS sender_username,r.username AS receiver_username FROM messages m JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.receiver_id WHERE (m.sender_id=$1 AND m.receiver_id=$2) OR (m.sender_id=$2 AND m.receiver_id=$1) ORDER BY m.id ASC`, [req.user.id, other]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

app.post("/api/messages", auth, async (req, res, next) => {
  try {
    const receiverId = Number(req.body.receiverId), body = cleanText(req.body.body, 4000);
    if (!Number.isInteger(receiverId) || !body) return res.status(400).json({ error: "Receiver and message required" });
    if (receiverId === req.user.id) return res.status(400).json({ error: "Cannot message yourself" });
    const target = await query("SELECT 1 FROM users WHERE id=$1", [receiverId]); if (!target.rowCount) return res.status(404).json({ error: "User not found" });
    const r = await query("INSERT INTO messages(sender_id,receiver_id,body) VALUES($1,$2,$3) RETURNING *", [req.user.id, receiverId, body]);
    res.status(201).json(r.rows[0]);
  } catch (e) { next(e); }
});

app.get("/api/inbox", auth, async (req, res, next) => {
  try {
    const r = await query(`SELECT u.id,u.username,u.name,u.avatar,
      (SELECT body FROM messages m2 WHERE ((m2.sender_id=$1 AND m2.receiver_id=u.id) OR (m2.sender_id=u.id AND m2.receiver_id=$1)) ORDER BY m2.id DESC LIMIT 1) AS last_message,
      (SELECT created_at FROM messages m3 WHERE ((m3.sender_id=$1 AND m3.receiver_id=u.id) OR (m3.sender_id=u.id AND m3.receiver_id=$1)) ORDER BY m3.id DESC LIMIT 1) AS last_time
      FROM users u WHERE u.id<>$1 ORDER BY last_time DESC NULLS LAST LIMIT 30`, [req.user.id]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

app.post("/api/support/tickets", auth, async (req, res, next) => {
  try {
    const subject = cleanText(req.body.subject, 160), message = cleanText(req.body.message, 5000);
    if (!subject || !message) return res.status(400).json({ error: "Subject and message required" });
    const r = await query("INSERT INTO support_tickets(user_id,subject,message) VALUES($1,$2,$3) RETURNING *", [req.user.id, subject, message]);
    res.status(201).json(r.rows[0]);
  } catch (e) { next(e); }
});
app.get("/api/support/tickets", auth, async (req, res, next) => {
  try { const r = await query("SELECT * FROM support_tickets WHERE user_id=$1 ORDER BY id DESC", [req.user.id]); res.json(r.rows); } catch (e) { next(e); }
});

if (!s3Enabled) app.use("/uploads", express.static(UPLOADS, { maxAge: "1y", immutable: true }));
app.use(express.static(PUBLIC, { extensions: ["html"] }));
app.get("*", (req, res) => res.sendFile(path.join(PUBLIC, "index.html")));

app.use((err, req, res, next) => {
  console.error(err);
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === "LIMIT_FILE_SIZE" ? "File is too large (max 100 MB)" : err.message });
  res.status(400).json({ error: err.message || "Request failed" });
});

initDb().then(() => {
  app.listen(PORT, "0.0.0.0", () => console.log(`VibeUp running on port ${PORT}`));
}).catch(err => { console.error("Database initialization failed", err); process.exit(1); });

process.on("SIGTERM", async () => { await pool.end(); process.exit(0); });
process.on("SIGINT", async () => { await pool.end(); process.exit(0); });
