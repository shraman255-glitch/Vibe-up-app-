# VibeUp — Production-ready starter

VibeUp is a social-video app starter with a mobile-first UI and a real backend for authentication, posts, likes, follows, inbox/DMs and Support Team tickets.

## Production architecture
- Node.js 20+ / Express
- PostgreSQL via `DATABASE_URL`
- S3-compatible object storage for images/videos (Cloudflare R2, AWS S3, Backblaze B2 S3 API, etc.)
- JWT authentication with a required production secret
- Helmet, CORS and API rate limiting
- Render deployment config included in `render.yaml`
- Local media fallback is available for development only

## Local development
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Provide a PostgreSQL `DATABASE_URL` (local Postgres is fine).
4. Leave S3 variables empty for local development; uploads use `./uploads`.
5. Run `npm install`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Production deployment
Set these environment variables in your hosting provider:
- `NODE_ENV=production`
- `JWT_SECRET` (long random secret)
- `DATABASE_URL` (managed PostgreSQL)
- `CORS_ORIGIN` (your public app URL)
- `S3_ENDPOINT`, `S3_REGION`, `S3_BUCKET`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_PUBLIC_BASE_URL`

The service listens on `0.0.0.0` and exposes `/api/health` for health checks.

## Media storage
Production uploads intentionally fail if S3-compatible storage is not configured. This prevents silently storing user videos on an ephemeral server disk. Configure a public bucket/CDN URL or adapt `saveMedia()` to your private-media/presigned-URL strategy.

## Still recommended before a large public launch
- Email verification and password reset
- Refresh-token/session revocation strategy
- Stronger abuse/rate-limit rules per endpoint
- Video transcoding, thumbnails and adaptive streaming (HLS/DASH)
- Image/video moderation and reporting
- Admin moderation dashboard with audited admin roles
- Push notifications
- Privacy policy, Terms, Community Guidelines, age/safety controls
- Automated database backups and monitoring/error tracking
- CDN and private object storage if media should not be publicly readable
- Automated tests and CI/CD
